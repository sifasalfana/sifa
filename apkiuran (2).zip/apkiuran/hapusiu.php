<?php
include 'koneksi.php';

$id = $_GET['ID'];
$panggildata= $koneksi -> query("SELECT * FROM iuran WHERE ID='$id' ");
$data =$panggildata ->fetch_assoc();
$hapus = $koneksi -> query("DELETE FROM iuran WHERE ID='$id'");
header('location:iuran.php');

?>