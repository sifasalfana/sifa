<?php
include 'koneksi.php';

$id = $_GET['NO_KK'];
$panggildata= $koneksi -> query("SELECT * FROM warga WHERE NO_KK='$id' ");
$data =$panggildata ->fetch_assoc();
$hapus = $koneksi -> query("DELETE FROM warga WHERE NO_KK='$id'");
header('location:warga.php');

?>