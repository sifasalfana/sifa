package com.sifasalfana.multi_page;

public class Data_profileku {
	
	//untuk data profil
	public static String  nama= "sifa salfana";
	public static int jml_aplikasi = 10;
	public static int jml_followers =10;
	public static int jml_following =10;
	public static String keterangan= "bla bla bla";
	
	//untuk login pengguna
	public static String username= "budi";
	public static String password= "12345";
	
	
}
