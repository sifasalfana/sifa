package com.sifasalfana.multi_page;

import android.media.Image;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Profile extends Activity {

	void tampilkanData() {

		TextView lblnama = (TextView) findViewById(R.id.namaku);
		lblnama.setText(Data_profileku.nama);

		TextView lbljmlapp = (TextView) findViewById(R.id.jmlapp);
		lbljmlapp.setText(String.valueOf(Data_profileku.jml_aplikasi));

		TextView lbljmlfollowers = (TextView) findViewById(R.id.jmlflwr);
		lbljmlfollowers.setText(String.valueOf(Data_profileku.jml_followers));

		TextView lbljmlfollowing = (TextView) findViewById(R.id.jmlflwg);
		lbljmlfollowing.setText(String.valueOf(Data_profileku.jml_following));

		TextView aboutNama = (TextView) findViewById(R.id.abtnama);
		aboutNama.setText("About" + Data_profileku.nama);

		TextView lblketerangan = (TextView) findViewById(R.id.ket);
		lblketerangan.setText(Data_profileku.keterangan);
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
        tampilkanData();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_profile);
		
		tampilkanData();

		ImageView btnback = (ImageView) findViewById(R.id.btnback);
		btnback.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(), Utama.class);
				startActivity(i);
				finish();
			}
		});
		Button btnlogout = (Button) findViewById(R.id.btnlogout);
		btnlogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		Button btn = (Button) findViewById(R.id.btnlogout);
		btnlogout.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(), Login.class);
				startActivity(i);
				finish();
			}
		});
		ImageView btnedit = (ImageView) findViewById(R.id.btnedit);
		btnedit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Intent i = new Intent(getApplicationContext(), Edit_page.class);
				startActivity(i);

			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.profile, menu);
		return true;
	}

}
