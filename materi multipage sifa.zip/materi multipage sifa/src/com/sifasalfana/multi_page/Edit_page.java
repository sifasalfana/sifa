package com.sifasalfana.multi_page;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class Edit_page extends Activity {
	EditText editnama, editapp, editflwr, editflwg, editket;
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit_page);
		
		editnama=(EditText)findViewById(R.id.editnama);
		editapp=(EditText)findViewById(R.id.editapp);
		editflwr=(EditText)findViewById(R.id.editflwr);
		editflwg=(EditText)findViewById(R.id.editflwg);
		editket=(EditText)findViewById(R.id.editket);
		
		editnama.setText(Data_profileku.nama);
		editapp.setText(String.valueOf(Data_profileku.jml_aplikasi));
		editflwr.setText(String.valueOf(Data_profileku.jml_followers));
		editflwg.setText(String.valueOf(Data_profileku.jml_following));
		editket.setText(Data_profileku.keterangan);
		
		
		ImageView btnback2=(ImageView)findViewById(R.id.btnback2);
		btnback2.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
			}
		});
		
		Button btnsv=(Button)findViewById(R.id.btnsv);
		btnsv.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Data_profileku.nama=editnama.getText().toString();
				Data_profileku.jml_aplikasi=  Integer.parseInt(editapp.getText().toString());
				Data_profileku.jml_followers=  Integer.parseInt(editflwr.getText().toString());
				Data_profileku.jml_following=  Integer.parseInt(editflwg.getText().toString());
				Data_profileku.keterangan=editket.getText().toString();
				Toast.makeText(getApplicationContext(), "Data berhasil disimpan", Toast.LENGTH_SHORT).show();
				finish();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.edit_page, menu);
		return true;
	}

}
